import React, { useState } from 'react';

const ClientList = ({ clients, onEdit, onDelete, onFilter }) => {
  const [searchTerm, setSearchTerm] = useState('');

  const handleSearch = (e) => {
    setSearchTerm(e.target.value);
  };

  const filteredClients = clients.filter(client =>
    client.nombre && client.nombre.toLowerCase().includes(searchTerm.toLowerCase())
  );

  return (
    <div className="p-6 bg-white rounded-lg shadow-xl max-w-4xl mx-auto mt-10">
      <h2 className="text-2xl font-bold mb-4 text-center">Lista de Clientes</h2>
      <div className="flex flex-col md:flex-row gap-4 mb-4">
        <input
          type="text"
          placeholder="Buscar por nombre"
          value={searchTerm}
          onChange={handleSearch}
          className="flex-grow px-4 py-2 bg-white border border-gray-300 rounded-lg shadow-sm focus:outline-none focus:ring-2 focus:ring-black transition"
        />
        <button
          onClick={onFilter}
          className="bg-blue-600 text-white py-2 px-4 rounded-lg hover:bg-blue-700 transition-colors shadow-md"
        >
          Filtrar por Vencimiento
        </button>
      </div>
      <div className="overflow-x-auto">
        <table className="min-w-full bg-white rounded-lg overflow-hidden">
          <thead className="bg-gray-100">
            <tr>
              <th className="py-2 px-4 text-left text-sm font-semibold text-gray-600">Nombre</th>
              <th className="py-2 px-4 text-left text-sm font-semibold text-gray-600">Correo</th>
              <th className="py-2 px-4 text-left text-sm font-semibold text-gray-600">Número</th>
              <th className="py-2 px-4 text-left text-sm font-semibold text-gray-600">Ingreso</th>
              <th className="py-2 px-4 text-left text-sm font-semibold text-gray-600">Vencimiento</th>
              <th className="py-2 px-4 text-left text-sm font-semibold text-gray-600">Acciones</th>
            </tr>
          </thead>
          <tbody>
            {filteredClients.map(client => (
              <tr key={client.id} className="border-b border-gray-200 hover:bg-gray-50">
                <td className="py-2 px-4 text-sm text-gray-800">{client.nombre}</td>
                <td className="py-2 px-4 text-sm text-gray-800">{client.correo}</td>
                <td className="py-2 px-4 text-sm text-gray-800">{client.numero}</td>
                <td className="py-2 px-4 text-sm text-gray-800">{client.fechaIngreso}</td>
                <td className="py-2 px-4 text-sm text-gray-800">{client.fechaVencimiento}</td>
                <td className="py-2 px-4 text-sm text-gray-800 flex gap-2">
                  <button
                    onClick={() => onEdit(client)}
                    className="bg-yellow-500 text-white py-1 px-3 rounded-lg text-xs hover:bg-yellow-600 transition-colors shadow-sm"
                  >
                    Editar
                  </button>
                  <button
                    onClick={() => onDelete(client.id)}
                    className="bg-red-600 text-white py-1 px-3 rounded-lg text-xs hover:bg-red-700 transition-colors shadow-sm"
                  >
                    Eliminar
                  </button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
};

export default ClientList;

// DONE