import React, { useState } from 'react';

const AdminLogin = ({ onLogin }) => {
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');

  const handleLogin = () => {
    if (password === 'Personal') {
      onLogin();
    } else {
      setError('Contraseña incorrecta');
    }
  };

  return (
    <div className="p-6 bg-white rounded-lg shadow-xl max-w-sm mx-auto mt-10">
      <h2 className="text-2xl font-bold mb-4 text-center">Acceso Administrador</h2>
      <input
        type="password"
        placeholder="Contraseña"
        value={password}
        onChange={(e) => setPassword(e.target.value)}
        className="w-full mt-3 px-4 py-2 bg-white border border-gray-300 rounded-lg shadow-sm focus:outline-none focus:ring-2 focus:ring-black transition"
      />
      {error && <p className="text-red-500 text-sm mt-2 text-center">{error}</p>}
      <button
        onClick={handleLogin}
        className="w-full mt-6 bg-black text-white py-2 rounded-lg hover:bg-gray-800 transition-colors shadow-md"
      >
        Ingresar
      </button>
    </div>
  );
};

export default AdminLogin;