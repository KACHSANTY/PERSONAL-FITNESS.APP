import React, { useState } from 'react';

const ClientStats = ({ clients }) => {
  const [searchName, setSearchName] = useState('');
  const [foundClient, setFoundClient] = useState(null);

  const handleSearch = () => {
    const client = clients.find(c => c.nombre && c.nombre.toLowerCase() === searchName.toLowerCase());
    setFoundClient(client);
  };

  return (
    <div className="p-6 bg-white rounded-lg shadow-xl max-w-md mx-auto mt-10">
      <h2 className="text-2xl font-bold mb-4 text-center">Mis Estadísticas</h2>
      <input
        type="text"
        placeholder="Ingresa tu nombre"
        value={searchName}
        onChange={(e) => setSearchName(e.target.value)}
        className="w-full mt-3 px-4 py-2 bg-white border border-gray-300 rounded-lg shadow-sm focus:outline-none focus:ring-2 focus:ring-black transition"
      />
      <button
        onClick={handleSearch}
        className="w-full mt-3 bg-black text-white py-2 rounded-lg hover:bg-gray-800 transition-colors shadow-md"
      >
        Buscar
      </button>

      {foundClient && (
        <div className="mt-6 border-t pt-4">
          <h3 className="text-xl font-bold mb-3">{foundClient.nombre}</h3>
          <p className="text-gray-700">Correo: {foundClient.correo}</p>
          <p className="text-gray-700">Número: {foundClient.numero}</p>
          <p className="text-gray-700">Edad: {foundClient.edad}</p>
          <p className="text-gray-700">Fecha de Ingreso: {foundClient.fechaIngreso}</p>
          <p className="text-gray-700">Fecha de Vencimiento: {foundClient.fechaVencimiento}</p>

          <h4 className="text-lg font-semibold mt-4 mb-2">Mediciones:</h4>
          {Object.keys(foundClient.mediciones).map((key) => (
            <p key={key} className="text-gray-700 text-sm capitalize">
              {key.replace(/([A-Z])/g, ' $1').trim()}: {foundClient.mediciones[key] || 'N/A'}
            </p>
          ))}
        </div>
      )}
       {!foundClient && searchName && (
        <p className="text-red-500 text-sm mt-4 text-center">Cliente no encontrado.</p>
      )}
    </div>
  );
};

export default ClientStats;