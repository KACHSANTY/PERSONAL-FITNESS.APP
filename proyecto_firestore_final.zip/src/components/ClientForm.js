import React, { useState } from 'react';

const ClientForm = ({ onRegister }) => {
  const [nombre, setNombre] = useState('');
  const [correo, setCorreo] = useState('');
  const [numero, setNumero] = useState('');
  const [fechaIngreso, setFechaIngreso] = useState('');
  const [edad, setEdad] = useState('');

  const handleSubmit = () => {
    if (nombre && correo && numero && fechaIngreso && edad) {
      const newClient = {
        id: Date.now().toString(), // Simple ID basado en timestamp
        nombre,
        correo,
        numero,
        fechaIngreso,
        edad,
        fechaVencimiento: new Date(new Date(fechaIngreso).setMonth(new Date(fechaIngreso).getMonth() + 1)).toISOString().split('T')[0], // Vencimiento 1 mes después
        mediciones: {
          cuello: '',
          pecho: '',
          brazoDerecho: '',
          brazoIzquierdo: '',
          cintura: '',
          cadera: '',
          muslos: '',
          pantorrillas: '',
        },
      };
      onRegister(newClient);
      setNombre('');
      setCorreo('');
      setNumero('');
      setFechaIngreso('');
      setEdad('');
    } else {
      alert('Por favor, llena todos los campos.');
    }
  };

  return (
    <div className="p-6 bg-white rounded-lg shadow-xl max-w-sm mx-auto">
      <h2 className="text-2xl font-bold mb-4 text-center">Registro de Cliente</h2>
      <input
        type="text"
        placeholder="Nombre"
        value={nombre}
        onChange={(e) => setNombre(e.target.value)}
        className="w-full mt-3 px-4 py-2 bg-white border border-gray-300 rounded-lg shadow-sm focus:outline-none focus:ring-2 focus:ring-black transition"
      />
      <input
        type="email"
        placeholder="Correo"
        value={correo}
        onChange={(e) => setCorreo(e.target.value)}
        className="w-full mt-3 px-4 py-2 bg-white border border-gray-300 rounded-lg shadow-sm focus:outline-none focus:ring-2 focus:ring-black transition"
      />
      <input
        type="text"
        placeholder="Número"
        value={numero}
        onChange={(e) => setNumero(e.target.value)}
        className="w-full mt-3 px-4 py-2 bg-white border border-gray-300 rounded-lg shadow-sm focus:outline-none focus:ring-2 focus:ring-black transition"
      />
      <input
        type="date"
        placeholder="Fecha de Ingreso"
        value={fechaIngreso}
        onChange={(e) => setFechaIngreso(e.target.value)}
        className="w-full mt-3 px-4 py-2 bg-white border border-gray-300 rounded-lg shadow-sm focus:outline-none focus:ring-2 focus:ring-black transition"
      />
       <input
        type="number"
        placeholder="Edad"
        value={edad}
        onChange={(e) => setEdad(e.target.value)}
        className="w-full mt-3 px-4 py-2 bg-white border border-gray-300 rounded-lg shadow-sm focus:outline-none focus:ring-2 focus:ring-black transition"
      />
      <div className="mt-4 text-center">
        <p className="text-sm text-gray-600">Sinpe: 8771-4703</p>
      </div>
      <button
        onClick={handleSubmit}
        className="w-full mt-6 bg-black text-white py-2 rounded-lg hover:bg-gray-800 transition-colors shadow-md"
      >
        Registrar
      </button>
    </div>
  );
};

export default ClientForm;