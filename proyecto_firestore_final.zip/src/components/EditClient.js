import React, { useState, useEffect } from 'react';

const EditClient = ({ client, onSave, onCancel }) => {
  const [editedClient, setEditedClient] = useState(client);

  useEffect(() => {
    setEditedClient(client);
  }, [client]);

  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setEditedClient({ ...editedClient, [name]: value });
  };

  const handleMeasurementChange = (e) => {
    const { name, value } = e.target;
    setEditedClient({
      ...editedClient,
      mediciones: {
        ...editedClient.mediciones,
        [name]: value,
      },
    });
  };

  const handleSave = () => {
    onSave(editedClient);
  };

  return (
    <div className="p-6 bg-white rounded-lg shadow-xl max-w-md mx-auto mt-10">
      <h2 className="text-2xl font-bold mb-4 text-center">Editar Cliente</h2>
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <div>
          <label className="block text-sm font-medium text-gray-700">Nombre</label>
          <input
            type="text"
            name="nombre"
            value={editedClient.nombre}
            onChange={handleInputChange}
            className="w-full mt-1 px-3 py-2 bg-white border border-gray-300 rounded-lg shadow-sm focus:outline-none focus:ring-2 focus:ring-black transition"
          />
        </div>
        <div>
          <label className="block text-sm font-medium text-gray-700">Correo</label>
          <input
            type="email"
            name="correo"
            value={editedClient.correo}
            onChange={handleInputChange}
            className="w-full mt-1 px-3 py-2 bg-white border border-gray-300 rounded-lg shadow-sm focus:outline-none focus:ring-2 focus:ring-black transition"
          />
        </div>
        <div>
          <label className="block text-sm font-medium text-gray-700">Número</label>
          <input
            type="text"
            name="numero"
            value={editedClient.numero}
            onChange={handleInputChange}
            className="w-full mt-1 px-3 py-2 bg-white border border-gray-300 rounded-lg shadow-sm focus:outline-none focus:ring-2 focus:ring-black transition"
          />
        </div>
        <div>
          <label className="block text-sm font-medium text-gray-700">Fecha Ingreso</label>
          <input
            type="date"
            name="fechaIngreso"
            value={editedClient.fechaIngreso}
            onChange={handleInputChange}
            className="w-full mt-1 px-3 py-2 bg-white border border-gray-300 rounded-lg shadow-sm focus:outline-none focus:ring-2 focus:ring-black transition"
          />
        </div>
        <div>
          <label className="block text-sm font-medium text-gray-700">Fecha Vencimiento</label>
          <input
            type="date"
            name="fechaVencimiento"
            value={editedClient.fechaVencimiento}
            onChange={handleInputChange}
            className="w-full mt-1 px-3 py-2 bg-white border border-gray-300 rounded-lg shadow-sm focus:outline-none focus:ring-2 focus:ring-black transition"
          />
        </div>
         <div>
          <label className="block text-sm font-medium text-gray-700">Edad</label>
          <input
            type="number"
            name="edad"
            value={editedClient.edad}
            onChange={handleInputChange}
            className="w-full mt-1 px-3 py-2 bg-white border border-gray-300 rounded-lg shadow-sm focus:outline-none focus:ring-2 focus:ring-black transition"
          />
        </div>
      </div>

      <h3 className="text-xl font-bold mt-6 mb-3 text-center">Mediciones</h3>
      <div className="grid grid-cols-2 gap-4">
        {Object.keys(editedClient.mediciones).map((key) => (
          <div key={key}>
            <label className="block text-sm font-medium text-gray-700 capitalize">{key.replace(/([A-Z])/g, ' $1').trim()}</label>
            <input
              type="text"
              name={key}
              value={editedClient.mediciones[key]}
              onChange={handleMeasurementChange}
              className="w-full mt-1 px-3 py-2 bg-white border border-gray-300 rounded-lg shadow-sm focus:outline-none focus:ring-2 focus:ring-black transition"
            />
          </div>
        ))}
      </div>

      <div className="flex justify-end gap-4 mt-6">
        <button
          onClick={onCancel}
          className="bg-gray-300 text-gray-800 py-2 px-4 rounded-lg hover:bg-gray-400 transition-colors shadow-md"
        >
          Cancelar
        </button>
        <button
          onClick={handleSave}
          className="bg-green-600 text-white py-2 px-4 rounded-lg hover:bg-green-700 transition-colors shadow-md"
        >
          Guardar Cambios
        </button>
      </div>
    </div>
  );
};

export default EditClient;