import React, { useState, useEffect } from 'react';
import ClientForm from './components/ClientForm';
import AdminLogin from './components/AdminLogin';
import ClientList from './components/ClientList';
import EditClient from './components/EditClient';
import ClientStats from './components/ClientStats';
import { createStorage, getStorage, setStorage } from './utils/storage';
import { initialClients } from './mock/clients';

const App = () => {
  const [currentPage, setCurrentPage] = useState('home'); // 'home', 'adminLogin', 'adminList', 'editClient', 'clientStats'
  // Usamos localStorage para simular la "nube" en este ejemplo.
  // En un proyecto real, aquí se harían llamadas a una API para obtener y guardar datos.
  const [clients, setClients] = useState(() => createStorage('clients', initialClients));
  const [selectedClient, setSelectedClient] = useState(null);

  useEffect(() => {
    // Guardar en localStorage cada vez que clients cambie
    setStorage('clients', clients);
  }, [clients]);

  const handleRegisterClient = (newClient) => {
    // En un proyecto real, aquí se enviaría el nuevo cliente a la API
    setClients([...clients, newClient]);
    alert('Cliente registrado con éxito!');
  };

  const handleAdminLogin = () => {
    // En un proyecto real, aquí se verificarían las credenciales con la API
    setCurrentPage('adminList');
  };

  const handleDeleteClient = (clientId) => {
    if (window.confirm('¿Estás seguro de eliminar este cliente?')) {
      // En un proyecto real, aquí se enviaría la solicitud de eliminación a la API
      setClients(clients.filter(client => client.id !== clientId));
    }
  };

  const handleEditClient = (client) => {
    setSelectedClient(client);
    setCurrentPage('editClient');
  };

  const handleSaveEditedClient = (updatedClient) => {
    // En un proyecto real, aquí se enviaría el cliente actualizado a la API
    setClients(clients.map(client =>
      client.id === updatedClient.id ? updatedClient : client
    ));
    setSelectedClient(null);
    setCurrentPage('adminList');
  };

  const handleCancelEdit = () => {
    setSelectedClient(null);
    setCurrentPage('adminList');
  };

  const handleFilterClients = () => {
    const today = new Date();
    const filtered = clients.filter(client => {
      const vencimiento = new Date(client.fechaVencimiento);
      const diffTime = vencimiento - today;
      const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
      return diffDays <= 5 && diffDays >= 0;
    });
    // Aquí iría la lógica para enviar correos automáticos (requiere backend)
    alert(`Clientes con vencimiento próximo (${filtered.length}): ${filtered.map(c => c.nombre).join(', ')}`);
  };

  return (
    <div className="min-h-screen bg-gray-100 p-6">
      <header className="flex flex-col md:flex-row justify-between items-center mb-6 gap-4">
        <div className="flex items-center gap-4">
          <img src="https://4tsix0yujj.ufs.sh/f/2vMRHqOYUHc0aM2fsN6MlP2v6X8etJWq7p3rj1iK9VwYu4nQ" alt="Personal Fitness Logo" className="h-10" />
          <h1 className="text-3xl font-bold text-gray-800">Personal Fitness</h1>
        </div>
        <div className="flex gap-4">
          <button
            onClick={() => setCurrentPage('clientStats')}
            className="bg-gray-800 text-white py-2 px-4 rounded-lg hover:bg-gray-900 transition-colors shadow-md"
          >
            Mis Estadísticas
          </button>
          <button
            onClick={() => setCurrentPage(currentPage === 'adminList' ? 'home' : 'adminLogin')}
            className="bg-gray-800 text-white py-2 px-4 rounded-lg hover:bg-gray-900 transition-colors shadow-md"
          >
            {currentPage === 'adminList' ? 'Inicio' : 'Admin'}
          </button>
        </div>
      </header>

      {currentPage === 'home' && (
        <ClientForm onRegister={handleRegisterClient} />
      )}

      {currentPage === 'adminLogin' && (
        <AdminLogin onLogin={handleAdminLogin} />
      )}

      {currentPage === 'adminList' && (
        <ClientList
          clients={clients}
          onEdit={handleEditClient}
          onDelete={handleDeleteClient}
          onFilter={handleFilterClients}
        />
      )}

      {currentPage === 'editClient' && selectedClient && (
        <EditClient
          client={selectedClient}
          onSave={handleSaveEditedClient}
          onCancel={handleCancelEdit}
        />
      )}

      {currentPage === 'clientStats' && (
        <ClientStats clients={clients} />
      )}
    </div>
  );
};

export default App;

// DONE